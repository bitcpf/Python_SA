#!/usr/bin/python

def sayhi():
    print 'Hi, this is mymodule speaking.'

version = '0.1'
