#filename:var.py
i=5
print i
i=i+1
print i

s='''This is a multi-line string.
This is the second line.'''
	print s

i = 5
print 'Value is', i # Error! Notice a single space at the start of the line
print 'I repeat, the value is', i

