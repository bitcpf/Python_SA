#!/usr/bin/python
#Filename : helloworld.py
print 'Hello World'
